#ifndef _MODEL_H
#define _MODEL_H

#include "Types.h"

void Model_Init(void);

#endif // _MODEL_H
