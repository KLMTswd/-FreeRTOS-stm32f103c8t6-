#ifndef _TIMERMODEL_H
#define _TIMERMODEL_H

#include "Types.h"

void TimerModel_UpdateTime(uint32 systemTime);

#endif // _TIMERMODEL_H
