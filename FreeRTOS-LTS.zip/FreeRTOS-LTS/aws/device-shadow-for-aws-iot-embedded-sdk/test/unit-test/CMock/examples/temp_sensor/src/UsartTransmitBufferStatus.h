#ifndef _USARTTRANSMITBUFFERSTATUS_H
#define _USARTTRANSMITBUFFERSTATUS_H

#include "Types.h"

bool Usart_ReadyToTransmit(void);

#endif // _USARTTRANSMITBUFFERSTATUS_H
