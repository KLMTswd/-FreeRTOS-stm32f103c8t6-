<table>
    <tr>
        <td colspan="3"><center><b>Code Size of AWS IoT Fleet Provisioning (example generated with GCC for ARM Cortex-M)</b></center></td>
    </tr>
    <tr>
        <td><b>File</b></td>
        <td><b><center>With -O1 Optimization</center></b></td>
        <td><b><center>With -Os Optimization</center></b></td>
    </tr>
    <tr>
        <td>fleet_provisioning.c</td>
        <td><center>1.0K</center></td>
        <td><center>0.9K</center></td>
    </tr>
    <tr>
        <td><b>Total estimates</b></td>
        <td><b><center>1.0K</center></b></td>
        <td><b><center>0.9K</center></b></td>
    </tr>
</table>
